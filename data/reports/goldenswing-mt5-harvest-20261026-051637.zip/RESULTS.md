# GoldenSwing MT5 harvest

harvested_utc: 2026-10-26T05:16:37.449031+00:00
scope: all
journal: None
feed: None
last_bar: (unknown)
last_price: (unknown)

## Results (from MT5 journal)

trades: 0
win_rate: 0.0%
total_R: +0.00R
avg_R: +0.00R
profit_factor: 0
total_pnl: +0.00
open_positions: 0

### Per playbook


### Today (UTC 2026-10-26)

closed: 0, total_R: +0.00R, PnL: +0.00

### Last 10 closed trades


### Open positions

(none)

## Tick CSVs in this bundle

(none — no tick CSVs in this scope)

## Files in this bundle


## Excluded by design

- chart PNGs (already ride the Telegram alerts)
- *.pkl / *.joblib binaries, .venv, wheels
- use /db for the single journal file, /ticks for a
  fresh tick-history export.
